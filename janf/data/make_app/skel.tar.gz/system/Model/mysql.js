var ROOT_PATH = require(process.env.INIT_CONFIG).config.ROOT_PATH;
var Model = require(ROOT_PATH + '/system/Model/Model');

/**
 * @class mysql
 * @inherits Model
 * @constructor
 */
mysql = function() {

    Model.Model.apply(this, arguments);
  
    var mysql = require('mysql');
    var connection = mysql.createConnection({
        host: this.config.host,
        user: this.config.username,
        password: this.config.password

    });

    this.query = function(text) {
  
        var q = 'SELECT * FROM node.clients WHERE 1';
  
        connection.query('USE ' + this.config.database);
        var proc = connection.query(text);

        return proc;

    }
}

exports.DB = mysql;