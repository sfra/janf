alert(x+"! It works");
alert(valueFromNodeJS);